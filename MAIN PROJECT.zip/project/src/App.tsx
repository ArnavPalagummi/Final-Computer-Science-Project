import { useState } from 'react';
import AboutMe from './components/AboutMe';
import Projects from './components/Projects';
import Navigation from './components/Navigation';

function App() {
  const [currentPage, setCurrentPage] = useState<'about' | 'projects'>('about');

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-green-100">
      <Navigation currentPage={currentPage} setCurrentPage={setCurrentPage} />
      <main className="container mx-auto px-4 py-8">
        {currentPage === 'about' ? <AboutMe /> : <Projects />}
      </main>
    </div>
  );
}

export default App;
