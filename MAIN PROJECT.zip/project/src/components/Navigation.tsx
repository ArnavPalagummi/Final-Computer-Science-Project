import { User, FolderOpen } from 'lucide-react';

interface NavigationProps {
  currentPage: 'about' | 'projects';
  setCurrentPage: (page: 'about' | 'projects') => void;
}

function Navigation({ currentPage, setCurrentPage }: NavigationProps) {
  return (
    <nav className="bg-emerald-700 shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <h1 className="text-white text-xl font-semibold">Arnav Palagummi</h1>
          <div className="flex space-x-1">
            <button
              onClick={() => setCurrentPage('about')}
              className={`flex items-center space-x-2 px-6 py-2 rounded-lg transition-all duration-200 ${
                currentPage === 'about'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-emerald-100 hover:bg-emerald-600 hover:text-white'
              }`}
            >
              <User size={18} />
              <span>About Me</span>
            </button>
            <button
              onClick={() => setCurrentPage('projects')}
              className={`flex items-center space-x-2 px-6 py-2 rounded-lg transition-all duration-200 ${
                currentPage === 'projects'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-emerald-100 hover:bg-emerald-600 hover:text-white'
              }`}
            >
              <FolderOpen size={18} />
              <span>Projects</span>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}

export default Navigation;
