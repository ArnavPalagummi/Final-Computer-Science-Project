import { useState } from 'react';
import { X, Play } from 'lucide-react';

function Projects() {
  const [text, setText] = useState('');
  const [videos, setVideos] = useState<string[]>([]);
  const [videoUrl, setVideoUrl] = useState('');
  const [images, setImages] = useState<string[]>([]);

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      Array.from(files).forEach((file) => {
        const reader = new FileReader();
        reader.onload = (event) => {
          if (event.target?.result) {
            setVideos((prev) => [...prev, event.target.result as string]);
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const addVideoUrl = () => {
    if (videoUrl.trim()) {
      setVideos((prev) => [...prev, videoUrl]);
      setVideoUrl('');
    }
  };

  const removeVideo = (index: number) => {
    setVideos((prev) => prev.filter((_, i) => i !== index));
  };

  const getYouTubeEmbedUrl = (url: string) => {
    const youtubeRegex = /(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\n?#]+)/;
    const match = url.match(youtubeRegex);
    return match ? `https://www.youtube.com/embed/${match[1]}` : null;
  };

  const getDriveEmbedUrl = (url: string) => {
    const driveRegex = /drive\.google\.com\/file\/d\/([a-zA-Z0-9-_]+)/;
    const match = url.match(driveRegex);
    return match ? `https://drive.google.com/file/d/${match[1]}/preview` : null;
  };

  const isYouTubeUrl = (url: string) => url.includes('youtube.com') || url.includes('youtu.be');
  const isDriveUrl = (url: string) => url.includes('drive.google.com');

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      Array.from(files).forEach((file) => {
        const reader = new FileReader();
        reader.onload = (event) => {
          if (event.target?.result) {
            setImages((prev) => [...prev, event.target.result as string]);
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const removeImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index));
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12">
        <h2 className="text-4xl font-bold text-emerald-800 mb-8 text-center">
          Projects
        </h2>

        <div className="space-y-6">
          {/* Video Upload Section */}
          <div>
            <label className="block text-sm font-medium text-emerald-700 mb-3">
              Upload Videos or Add Video Links
            </label>
            <div className="space-y-3">
              <input
                type="file"
                multiple
                accept="video/*"
                onChange={handleVideoUpload}
                className="block w-full text-sm text-gray-600 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-emerald-100 file:text-emerald-700 hover:file:bg-emerald-200 cursor-pointer"
              />
              <div className="flex gap-2">
                <input
                  type="text"
                  value={videoUrl}
                  onChange={(e) => setVideoUrl(e.target.value)}
                  placeholder="Or paste YouTube/Google Drive URL..."
                  className="flex-1 px-4 py-2 border-2 border-emerald-200 rounded-lg focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 transition-all text-sm"
                  onKeyPress={(e) => e.key === 'Enter' && addVideoUrl()}
                />
                <button
                  onClick={addVideoUrl}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition-colors font-medium text-sm"
                >
                  Add
                </button>
              </div>
            </div>
          </div>

          {/* Video Display */}
          {videos.length > 0 && (
            <div>
              <p className="text-sm font-medium text-emerald-700 mb-4">
                Videos ({videos.length})
              </p>
              <div className="space-y-4">
                {videos.map((video, index) => (
                  <div key={index} className="relative group bg-gray-100 rounded-lg overflow-hidden">
                    {video.startsWith('blob:') || video.startsWith('data:') ? (
                      <video
                        src={video}
                        controls
                        className="w-full h-80 bg-black rounded-lg"
                      />
                    ) : isYouTubeUrl(video) ? (
                      <iframe
                        width="100%"
                        height="320"
                        src={getYouTubeEmbedUrl(video) || ''}
                        title={`Video ${index + 1}`}
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                        className="rounded-lg"
                      />
                    ) : isDriveUrl(video) ? (
                      <iframe
                        src={getDriveEmbedUrl(video) || ''}
                        width="100%"
                        height="320"
                        allow="autoplay"
                        className="rounded-lg"
                      />
                    ) : (
                      <div className="w-full h-80 bg-gray-300 rounded-lg flex items-center justify-center">
                        <Play className="text-gray-500" size={48} />
                      </div>
                    )}
                    <button
                      onClick={() => removeVideo(index)}
                      className="absolute top-2 right-2 bg-red-500 hover:bg-red-600 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-10"
                    >
                      <X size={18} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Text Input */}
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            className="w-full h-96 p-4 border-2 border-emerald-200 rounded-lg focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 transition-all resize-none"
            placeholder="Enter your project details here..."
          />

          {/* Image Upload */}
          <div>
            <label className="block text-sm font-medium text-emerald-700 mb-3">
              Add Images
            </label>
            <input
              type="file"
              multiple
              accept="image/*"
              onChange={handleImageUpload}
              className="block w-full text-sm text-gray-600 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-emerald-100 file:text-emerald-700 hover:file:bg-emerald-200 cursor-pointer"
            />
          </div>

          {/* Image Display */}
          {images.length > 0 && (
            <div>
              <p className="text-sm font-medium text-emerald-700 mb-4">
                Uploaded Images ({images.length})
              </p>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {images.map((image, index) => (
                  <div key={index} className="relative group">
                    <img
                      src={image}
                      alt={`Project ${index + 1}`}
                      className="w-full h-40 object-cover rounded-lg shadow-md"
                    />
                    <button
                      onClick={() => removeImage(index)}
                      className="absolute top-2 right-2 bg-red-500 hover:bg-red-600 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X size={18} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default Projects;
