function AboutMe() {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12">
        <h2 className="text-4xl font-bold text-emerald-800 mb-8 text-center">
          About Me
        </h2>

        <div className="space-y-6 text-gray-700 leading-relaxed">
          <p className="text-lg">
            Wealth belongs to those who can think smart, and act smart. My name is <span className="font-semibold text-emerald-700">Arnav Palagummi</span>, and I am a ninth grade student at Emerald High School in Dublin, California. My career goal is to go into a mathematics or computer science related field, such as data engineering or AI architecture. I plan to achieve these goals by maintaining high GPA's, participating in community projects, completing extracurricular activities, and joining multiple clubs. One of my other main goals is to be able to get into a good college, such as an IVY league or a prestigious college nearby here in California. I chose this path because I am passionate about this field, and want to get a stable job to keep my family and I secure in the future.
          </p>

          <p className="text-lg">
            I possess many character traits which are useful to go into this field of STEM. Some of these characteristics would be that I am patient, open minded, knowledgeable, and flexible. For example, I have studied and learned vocal singing for almost 8 years, and recently competed in an international competition which requires multiple consistent hours of practice and memorization. In order to get the high score that I received, I needed to memorize over 75 pages of theory on the history of singing. I also had to memorize 20 songs and perform them. This experience taught me to master complex information in a very short amount of time, and with precision as well.
          </p>

          <p className="text-lg">
            I also started a leadership program to benefit the community. Back in May of 2025, me and a few of my friends decided to continue an idea that we started during a school project. The main purpose of this project was to distribute multiple vials of NARCAN (Nalaxone), to classes and schools all around California, to prevent any deaths from accidental overdoses. This project requires significant knowledge as well as organization and team work. Me and my group had to contact multiple hospitals in order to see whether they would fund us or not. Balancing this work on top of doing multiple advanced courses did not come from luck, but rather from these character traits that I have developed over the years.
          </p>

          <p className="text-lg font-medium text-emerald-700 text-center mt-8">
            I hope to do good in whatever I choose to do in the future, and improve on myself as a character. Thank you for your time, and have a fantastic rest of your day!
          </p>
        </div>
      </div>
    </div>
  );
}

export default AboutMe;
